const SUPABASE_URL = "https://kozhczffkulvhxzbwsfl.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable__wqs-rPYa-lfNwDj0E5y4g_FKwWsA8F";

const START_YEAR = 2026;
const START_MONTH = 6; // Junio
const MONTH_COUNT = 60;
const DEFAULT_EXCHANGE_RATE = 1427.64;
const DEFAULT_INCOME_USD = 0;
const DEFAULT_TARGET_USD = 300;

const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
const shortMonths = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];

// Cuentas nuevas: arrancan limpias para que la app pueda compartirse con otras personas.
const defaultFixedExpenses = [];

// Plantilla personal recuperable desde el Excel de Diana.
// No se aplica automáticamente a otros usuarios: solo se carga si tocás el botón "Restaurar plantilla Excel".
const personalFixedExpenses = [
  { icon: "🏠", category: "Casa", name: "Alquiler", amount: 330000, paid: false },
  { icon: "💡", category: "Servicios", name: "Luz promedio", amount: 99442.6, paid: false },
  { icon: "🌐", category: "Servicios", name: "Internet", amount: 23740, paid: false },
  { icon: "💼", category: "Trabajo", name: "Secretaria", amount: 330000, paid: false },
  { icon: "🧘", category: "Salud", name: "Gimnasio", amount: 223000, paid: false },
  { icon: "🎬", category: "Ocio", name: "Teatro", amount: 20000, paid: false },
  { icon: "🎓", category: "Educación", name: "Academia inglés hija", amount: 90500, paid: false },
  { icon: "🤖", category: "Trabajo", name: "ChatGPT USD 39", amount: 55677.96, paid: false },
  { icon: "💳", category: "Cuotas / deudas", name: "Cuota Flip", amount: 40000, paid: false },
  { icon: "🧾", category: "Trabajo", name: "Licencias varias", amount: 20000, paid: false },
  { icon: "🎓", category: "Educación", name: "Carrera de ingeniería", amount: 154000, paid: false }
];

const personalVariableExpenses = [
  { icon: "🍽️", category: "Comida", name: "Menú mediodía", amount: 132000 },
  { icon: "🛒", category: "Supermercado", name: "Supermercado / cenas / desayuno / comida casa", amount: 420000 },
  { icon: "🚗", category: "Transporte", name: "Transporte / combustible / movilidad", amount: 120000 },
  { icon: "🎓", category: "Educación", name: "Gastos hija / extras escolares / ropa chica", amount: 120000 },
  { icon: "🧘", category: "Salud", name: "Salud / farmacia / belleza / varios necesarios", amount: 80000 },
  { icon: "🎬", category: "Ocio", name: "Salidas / ocio controlado", amount: 70000 },
  { icon: "✨", category: "Otros", name: "Gasto hormiga libre", amount: 120000 },
  { icon: "🧯", category: "Imprevistos", name: "Imprevistos / colchón de ajuste", amount: 211476.2 }
];

const categoryIcons = {
  "Casa": "🏠",
  "Servicios": "💡",
  "Trabajo": "💼",
  "Salud": "🧘",
  "Educación": "🎓",
  "Comida": "🍽️",
  "Supermercado": "🛒",
  "Transporte": "🚗",
  "Ocio": "🎬",
  "Cuotas / deudas": "💳",
  "Imprevistos": "🧯",
  "Otros": "✨"
};

const dailyStatusMemes = {
  ok: "assets/memes/meme-ok.png",
  limit: "assets/memes/meme-limite.png",
  over: "assets/memes/meme-pasada.png",
  drama: "assets/memes/meme-drama.png"
};

const flowSteps = [
  { key: "inicio", icon: "🏁", label: "Inicio" },
  { key: "mes", icon: "⚙️", label: "Datos del mes" },
  { key: "gastos", icon: "🏠", label: "Gastos" },
  { key: "dia", icon: "⚡", label: "Carga diaria" },
  { key: "semana", icon: "📆", label: "Resumen semanal" },
  { key: "metas", icon: "🎯", label: "Metas" },
  { key: "calendario", icon: "🗓️", label: "Calendario" },
  { key: "anio", icon: "📈", label: "Año" }
];

const state = {
  session: null,
  user: null,
  months: [],
  goals: [],
  current: null,
  mode: "login",
  savingTimer: null,
  goalSavingTimer: null,
  isBootstrapping: false,
  goalsEnabled: true,
  flowIndex: 0,
  // v10: la app queda siempre en modo secciones. Ya no muestra todo el chorizo junto.
  guidedMode: true
};

const client = supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

const $ = (id) => document.getElementById(id);
const els = {
  authScreen: $("authScreen"),
  appScreen: $("appScreen"),
  loginTab: $("loginTab"),
  signupTab: $("signupTab"),
  authForm: $("authForm"),
  emailInput: $("emailInput"),
  passwordInput: $("passwordInput"),
  authSubmit: $("authSubmit"),
  authMessage: $("authMessage"),
  logoutBtn: $("logoutBtn"),
  seedBtn: $("seedBtn"),
  resetMonthBtn: $("resetMonthBtn"),
  restoreTemplateBtn: $("restoreTemplateBtn"),
  welcomeText: $("welcomeText"),
  monthSelect: $("monthSelect"),
  saveStatus: $("saveStatus"),
  flowTrack: $("flowTrack"),
  flowPrevBtn: $("flowPrevBtn"),
  flowNextBtn: $("flowNextBtn"),
  flowToggleBtn: $("flowToggleBtn"),
  sidebarMonthLabel: $("sidebarMonthLabel"),
  monthTitle: $("monthTitle"),
  monthCircle: $("monthCircle"),
  monthPercent: $("monthPercent"),
  incomeConvertedView: $("incomeConvertedView"),
  targetSavingsView: $("targetSavingsView"),
  actualSavingsView: $("actualSavingsView"),
  totalSavedView: $("totalSavedView"),
  fiveYearGoalView: $("fiveYearGoalView"),
  globalPercent: $("globalPercent"),
  globalProgressBar: $("globalProgressBar"),
  globalSavedLabel: $("globalSavedLabel"),
  globalRemainingLabel: $("globalRemainingLabel"),
  currencyInput: $("currencyInput"),
  exchangeRateInput: $("exchangeRateInput"),
  incomeUsdInput: $("incomeUsdInput"),
  incomeArsViewInput: $("incomeArsViewInput"),
  incomeTotalView: $("incomeTotalView"),
  targetInput: $("targetInput"),
  actualSavingsInput: $("actualSavingsInput"),
  notesInput: $("notesInput"),
  saveNowBtn: $("saveNowBtn"),
  fixedTotalView: $("fixedTotalView"),
  fixedPaidView: $("fixedPaidView"),
  fixedPendingView: $("fixedPendingView"),
  variableTotalView: $("variableTotalView"),
  dailyTotalView: $("dailyTotalView"),
  dailyBudgetView: $("dailyBudgetView"),
  weeklyBudgetView: $("weeklyBudgetView"),
  selectedDaySpentView: $("selectedDaySpentView"),
  selectedDayBalanceView: $("selectedDayBalanceView"),
  selectedAccumBudgetView: $("selectedAccumBudgetView"),
  selectedAccumSpentView: $("selectedAccumSpentView"),
  selectedAccumBalanceView: $("selectedAccumBalanceView"),
  compensatedDailyView: $("compensatedDailyView"),
  availableView: $("availableView"),
  fixedList: $("fixedList"),
  variableList: $("variableList"),
  addFixedBtn: $("addFixedBtn"),
  addVariableBtn: $("addVariableBtn"),
  entryDayInput: $("entryDayInput"),
  entryCategoryInput: $("entryCategoryInput"),
  entryAmountInput: $("entryAmountInput"),
  entryNoteInput: $("entryNoteInput"),
  addEntryBtn: $("addEntryBtn"),
  dailyStatusCard: $("dailyStatusCard"),
  dailyStatusMeme: $("dailyStatusMeme"),
  dailyStatusTitle: $("dailyStatusTitle"),
  dailyStatusText: $("dailyStatusText"),
  dailyBudgetMini: $("dailyBudgetMini"),
  dailySpentMini: $("dailySpentMini"),
  dailyBalanceMini: $("dailyBalanceMini"),
  whatsappSummaryBtn: $("whatsappSummaryBtn"),
  categoryBreakdown: $("categoryBreakdown"),
  weeklyBreakdown: $("weeklyBreakdown"),
  goalIconInput: $("goalIconInput"),
  goalNameInput: $("goalNameInput"),
  goalTargetInput: $("goalTargetInput"),
  goalSavedInput: $("goalSavedInput"),
  goalMonthlyInput: $("goalMonthlyInput"),
  addGoalBtn: $("addGoalBtn"),
  goalsList: $("goalsList"),
  calendarGrid: $("calendarGrid"),
  clearMonthBtn: $("clearMonthBtn"),
  yearChartTitle: $("yearChartTitle"),
  yearBars: $("yearBars"),
  expenseTemplate: $("expenseRowTemplate")
};

function formatMoney(value, currency = "ARS") {
  const n = Number(value || 0);
  const rounded = Math.round(n * 100) / 100;
  const locale = "es-AR";
  const code = (currency || "ARS").toUpperCase();
  if (code === "USD") return `USD ${rounded.toLocaleString(locale, { maximumFractionDigits: 2 })}`;
  return `${code} ${rounded.toLocaleString(locale, { maximumFractionDigits: 2 })}`;
}

function formatUsd(value) {
  return `USD ${Number(value || 0).toLocaleString("es-AR", { maximumFractionDigits: 2 })}`;
}

function formatPercent(value) {
  return `${Number(value || 0).toLocaleString("es-AR", { maximumFractionDigits: 1 })}%`;
}

function clampPercent(value) {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, value));
}

function getMonthKey(year, month) {
  return `${year}-${String(month).padStart(2, "0")}`;
}

function cloneDefaultFixedExpenses() {
  return defaultFixedExpenses.map((item) => ({ ...item }));
}

function getFiveYearMonths() {
  const months = [];
  let year = START_YEAR;
  let month = START_MONTH;
  for (let i = 0; i < MONTH_COUNT; i++) {
    months.push({ year, month, month_key: getMonthKey(year, month) });
    month += 1;
    if (month > 12) {
      month = 1;
      year += 1;
    }
  }
  return months;
}

function daysInMonth(year, month) {
  return new Date(year, month, 0).getDate();
}

function addMonths(date, months) {
  const result = new Date(date.getFullYear(), date.getMonth() + months, 1);
  return `${monthNames[result.getMonth()]} ${result.getFullYear()}`;
}

function setMessage(text, isError = false) {
  els.authMessage.textContent = text;
  els.authMessage.style.color = isError ? "#ff9aa8" : "#f2c14e";
}

function setSaveStatus(text, status = "idle") {
  els.saveStatus.textContent = text;
  els.saveStatus.className = `save-status ${status}`;
}

function showAuth() {
  els.authScreen.classList.remove("hidden");
  els.appScreen.classList.add("hidden");
}

function showApp() {
  els.authScreen.classList.add("hidden");
  els.appScreen.classList.remove("hidden");
  applyFlowView();
}

function renderFlowNav() {
  if (!els.flowTrack) return;
  els.flowTrack.innerHTML = "";
  flowSteps.forEach((step, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "flow-step-btn";
    button.dataset.flowKey = step.key;
    button.innerHTML = `<span class="flow-icon">${step.icon}</span><span>${step.label}</span>`;
    button.addEventListener("click", () => setFlowStep(index));
    els.flowTrack.appendChild(button);
  });
  applyFlowView();
}

function setFlowStep(index) {
  const safeIndex = Math.max(0, Math.min(flowSteps.length - 1, Number(index || 0)));
  state.flowIndex = safeIndex;
  state.guidedMode = true;
  applyFlowView();
  requestAnimationFrame(() => {
    document.querySelector(".app-content")?.scrollTo({ top: 0, behavior: "smooth" });
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

function nextFlowStep() {
  setFlowStep(state.flowIndex + 1);
}

function prevFlowStep() {
  setFlowStep(state.flowIndex - 1);
}

function toggleFlowMode() {
  // v10: se elimina la vista completa para que cada pantalla muestre solo su sección.
  state.guidedMode = true;
  applyFlowView();
}

function applyFlowView() {
  const sections = document.querySelectorAll("#appScreen [data-flow-step]");
  if (!sections.length) return;
  const activeKey = flowSteps[state.flowIndex]?.key || flowSteps[0].key;
  state.guidedMode = true;
  els.appScreen?.classList.add("guided-mode");

  sections.forEach((section) => {
    const isActive = section.dataset.flowStep === activeKey;
    section.hidden = !isActive;
    section.classList.toggle("active-flow-section", isActive);
  });

  if (els.flowTrack) {
    [...els.flowTrack.querySelectorAll(".flow-step-btn")].forEach((button, index) => {
      const active = index === state.flowIndex;
      button.classList.toggle("active", active);
      if (active) {
        setTimeout(() => button.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" }), 0);
      }
    });
  }

  if (els.flowPrevBtn) els.flowPrevBtn.disabled = state.flowIndex === 0;
  if (els.flowNextBtn) els.flowNextBtn.disabled = state.flowIndex === flowSteps.length - 1;
  if (els.flowToggleBtn) els.flowToggleBtn.hidden = true;
}

function attachFlowSwipe() {
  if (!els.appScreen) return;
  let startX = 0;
  let startY = 0;
  els.appScreen.addEventListener("touchstart", (event) => {
    if (!event.touches?.length) return;
    startX = event.touches[0].clientX;
    startY = event.touches[0].clientY;
  }, { passive: true });
  els.appScreen.addEventListener("touchend", (event) => {
    if (!event.changedTouches?.length) return;
    const dx = event.changedTouches[0].clientX - startX;
    const dy = event.changedTouches[0].clientY - startY;
    if (Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy) * 1.25) {
      if (dx < 0) nextFlowStep();
      else prevFlowStep();
    }
  }, { passive: true });
}

function setAuthMode(mode) {
  state.mode = mode;
  els.loginTab.classList.toggle("active", mode === "login");
  els.signupTab.classList.toggle("active", mode === "signup");
  els.authSubmit.textContent = mode === "login" ? "Ingresar" : "Crear cuenta";
  setMessage("");
}

async function handleAuthSubmit(event) {
  event.preventDefault();
  const email = els.emailInput.value.trim();
  const password = els.passwordInput.value;
  els.authSubmit.disabled = true;
  setMessage(state.mode === "login" ? "Ingresando..." : "Creando cuenta...");

  try {
    const response = state.mode === "login"
      ? await client.auth.signInWithPassword({ email, password })
      : await client.auth.signUp({ email, password });

    if (response.error) throw response.error;

    if (state.mode === "signup" && !response.data.session) {
      setMessage("Cuenta creada. Revisá tu correo para confirmar y después ingresá.");
    } else {
      setMessage("Listo, cargando tu tablero...");
      await bootApp();
    }
  } catch (error) {
    setMessage(error.message || "No se pudo completar la acción.", true);
  } finally {
    els.authSubmit.disabled = false;
  }
}

async function logout() {
  await client.auth.signOut();
  state.session = null;
  state.user = null;
  state.months = [];
  state.goals = [];
  state.current = null;
  showAuth();
}

function normalizeExpense(item, type = "variable") {
  const name = item?.name || item?.concept || "";
  const category = item?.category || guessCategory(name) || "Otros";
  return {
    icon: item?.icon || categoryIcons[category] || "🧾",
    category,
    name,
    amount: Number(item?.amount || 0),
    paid: type === "fixed" ? Boolean(item?.paid) : false
  };
}

function normalizeMonth(row) {
  return {
    ...row,
    currency: row.currency || "ARS",
    exchange_rate: Number(row.exchange_rate || DEFAULT_EXCHANGE_RATE),
    income_total: Number(row.income_total || 0), // En esta app se usa como ingreso mensual en USD.
    target_savings_usd: Number(row.target_savings_usd || DEFAULT_TARGET_USD),
    actual_savings_usd: Number(row.actual_savings_usd || 0),
    fixed_expenses: Array.isArray(row.fixed_expenses) ? row.fixed_expenses.map((x) => normalizeExpense(x, "fixed")) : [],
    variable_expenses: Array.isArray(row.variable_expenses) ? row.variable_expenses.map((x) => normalizeExpense(x, "variable")) : [],
    daily_entries: Array.isArray(row.daily_entries) ? row.daily_entries : [],
    notes: row.notes || ""
  };
}

function guessCategory(name = "") {
  const n = String(name).toLowerCase();
  if (n.includes("alquiler") || n.includes("casa")) return "Casa";
  if (n.includes("luz") || n.includes("internet") || n.includes("servicio")) return "Servicios";
  if (n.includes("secretaria") || n.includes("chatgpt") || n.includes("licencia")) return "Trabajo";
  if (n.includes("gym") || n.includes("gimnasio") || n.includes("salud") || n.includes("farmacia")) return "Salud";
  if (n.includes("academia") || n.includes("inglés") || n.includes("carrera") || n.includes("ingeniería")) return "Educación";
  if (n.includes("menú") || n.includes("menu") || n.includes("comida")) return "Comida";
  if (n.includes("super")) return "Supermercado";
  if (n.includes("transporte") || n.includes("combustible")) return "Transporte";
  if (n.includes("teatro") || n.includes("salida") || n.includes("ocio")) return "Ocio";
  if (n.includes("cuota") || n.includes("deuda") || n.includes("flip")) return "Cuotas / deudas";
  return "Otros";
}

function cleanFixedExpenses(currentFixed = []) {
  return (currentFixed || [])
    .map((x) => normalizeExpense(x, "fixed"))
    .filter((x) => String(x.name || "").trim() !== "");
}

function mergeExpensesByName(template = [], current = [], type = "variable") {
  const currentClean = (current || [])
    .map((x) => normalizeExpense(x, type))
    .filter((x) => String(x.name || "").trim() !== "");
  const byName = new Map(currentClean.map((x) => [String(x.name || "").trim().toLowerCase(), x]));
  const result = [];

  for (const item of template) {
    const key = String(item.name || "").trim().toLowerCase();
    const existing = byName.get(key);
    result.push({
      ...item,
      amount: Number(item.amount || 0),
      paid: type === "fixed" ? Boolean(existing?.paid) : false
    });
    byName.delete(key);
  }

  for (const custom of byName.values()) result.push(custom);
  return result;
}

async function restorePersonalExcelTemplate() {
  if (!state.user || !state.months.length) return;
  const ok = confirm(
    "Voy a restaurar la plantilla del Excel en tus 60 meses: fijos, variables, ingreso USD 2009, dólar ref. 1427,64 y ahorro objetivo USD 300. No borra tus gastos diarios ni tus metas. ¿Seguimos?"
  );
  if (!ok) return;

  setSaveStatus("Restaurando plantilla...", "saving");
  const updates = [];
  for (const month of state.months) {
    const fixed = mergeExpensesByName(personalFixedExpenses, month.fixed_expenses || [], "fixed");
    const variables = mergeExpensesByName(personalVariableExpenses, month.variable_expenses || [], "variable");
    month.fixed_expenses = fixed;
    month.variable_expenses = variables;
    month.income_total = Number(month.income_total || 0) > 0 ? month.income_total : 2009;
    month.exchange_rate = Number(month.exchange_rate || 0) > 0 ? month.exchange_rate : DEFAULT_EXCHANGE_RATE;
    month.target_savings_usd = Number(month.target_savings_usd || 0) > 0 ? month.target_savings_usd : DEFAULT_TARGET_USD;
    updates.push({
      id: month.id,
      fixed_expenses: fixed,
      variable_expenses: variables,
      income_total: month.income_total,
      exchange_rate: month.exchange_rate,
      target_savings_usd: month.target_savings_usd
    });
  }

  for (const update of updates) {
    const { error } = await client
      .from("finance_months")
      .update({
        fixed_expenses: update.fixed_expenses,
        variable_expenses: update.variable_expenses,
        income_total: update.income_total,
        exchange_rate: update.exchange_rate,
        target_savings_usd: update.target_savings_usd,
        updated_at: new Date().toISOString()
      })
      .eq("id", update.id)
      .eq("user_id", state.user.id);
    if (error) {
      setSaveStatus("Error al restaurar", "error");
      alert(error.message);
      return;
    }
  }

  await loadMonths();
  if (state.current) {
    const fresh = state.months.find((m) => m.month_key === state.current.month_key);
    if (fresh) state.current = normalizeMonth(fresh);
  }
  renderMonthOptions();
  renderCurrentMonth();
  setSaveStatus("Plantilla restaurada", "saved");
  alert("Listo: restauré tus fijos y variables del Excel. Para compartir la app, las cuentas nuevas siguen arrancando limpias.");
}

function looksLikeInheritedDianaTemplate(month) {
  const fixed = (month.fixed_expenses || []).map((x) => String(x.name || "").toLowerCase());
  const personalMarks = [
    "academia inglés hija",
    "academia ingles hija",
    "secretaria",
    "chatgpt usd 39",
    "carrera de ingeniería",
    "carrera de ingenieria",
    "cuota flip"
  ];
  const hits = personalMarks.filter((mark) => fixed.some((name) => name.includes(mark))).length;
  return hits >= 2;
}

async function cleanInheritedTemplateForSharedUsers() {
  if (!state.user || !state.months.length) return;
  const ownerEmail = "diana.starckcomex@gmail.com";
  const email = String(state.user.email || "").toLowerCase();
  if (email === ownerEmail) return;

  const updates = [];
  for (const month of state.months) {
    if (looksLikeInheritedDianaTemplate(month)) {
      month.fixed_expenses = [];
      if (Number(month.income_total || 0) === 2009) month.income_total = 0;
      updates.push({ id: month.id, fixed_expenses: [], income_total: month.income_total });
    }
  }

  for (const update of updates) {
    await client
      .from("finance_months")
      .update({
        fixed_expenses: update.fixed_expenses,
        income_total: update.income_total,
        updated_at: new Date().toISOString()
      })
      .eq("id", update.id)
      .eq("user_id", state.user.id);
  }

  if (updates.length) {
    await loadMonths();
  }
}

async function loadMonths() {
  const { data, error } = await client
    .from("finance_months")
    .select("*")
    .eq("user_id", state.user.id)
    .order("year", { ascending: true })
    .order("month", { ascending: true });

  if (error) throw error;
  state.months = (data || []).map(normalizeMonth);
}

async function ensureMonths() {
  if (!state.user) return;
  state.isBootstrapping = true;
  setSaveStatus("Revisando meses...", "saving");
  const needed = getFiveYearMonths();
  const existingKeys = new Set(state.months.map((m) => m.month_key));
  const rows = needed
    .filter((m) => !existingKeys.has(m.month_key))
    .map((m) => ({
      user_id: state.user.id,
      month_key: m.month_key,
      year: m.year,
      month: m.month,
      currency: "ARS",
      exchange_rate: DEFAULT_EXCHANGE_RATE,
      income_total: DEFAULT_INCOME_USD,
      target_savings_usd: DEFAULT_TARGET_USD,
      actual_savings_usd: 0,
      fixed_expenses: cloneDefaultFixedExpenses(),
      variable_expenses: [],
      daily_entries: [],
      notes: ""
    }));

  if (rows.length) {
    const { error } = await client.from("finance_months").insert(rows);
    if (error) throw error;
  }
  state.isBootstrapping = false;
  await loadMonths();
  setSaveStatus(rows.length ? `${rows.length} meses creados` : "Meses listos", "saved");
}

async function loadGoals() {
  if (!state.user) return;
  const { data, error } = await client
    .from("savings_goals")
    .select("*")
    .eq("user_id", state.user.id)
    .order("created_at", { ascending: true });

  if (error) {
    state.goalsEnabled = false;
    state.goals = [];
    console.warn("No pude cargar savings_goals. Ejecutá el SQL actualizado.", error);
    return;
  }
  state.goalsEnabled = true;
  state.goals = data || [];
}

async function bootApp() {
  const { data } = await client.auth.getSession();
  state.session = data.session;
  state.user = data.session?.user || null;

  if (!state.user) {
    showAuth();
    return;
  }

  showApp();
  els.welcomeText.textContent = state.user.email ? `Sesión activa: ${state.user.email}` : "Sesión activa";
  setSaveStatus("Cargando datos...", "saving");

  try {
    await loadMonths();
    await ensureMonths();
    await loadGoals();
    renderMonthOptions();
    const first = state.months.find((m) => m.month_key === getMonthKey(START_YEAR, START_MONTH)) || state.months[0];
    selectMonth(first?.month_key);
    renderGoals();
    setSaveStatus("Datos sincronizados", "saved");
  } catch (error) {
    console.error(error);
    setSaveStatus("Error de conexión", "error");
    alert(`No pude cargar la base. Revisá que hayas ejecutado el SQL en Supabase.\n\nDetalle: ${error.message}`);
  }
}

function renderMonthOptions() {
  els.monthSelect.innerHTML = "";
  state.months.forEach((m) => {
    const opt = document.createElement("option");
    opt.value = m.month_key;
    opt.textContent = `${monthNames[m.month - 1]} ${m.year}`;
    els.monthSelect.appendChild(opt);
  });
}

function selectMonth(monthKey) {
  const row = state.months.find((m) => m.month_key === monthKey);
  if (!row) return;
  state.current = normalizeMonth(row);
  els.monthSelect.value = monthKey;
  renderCurrentMonth();
}

function renderCurrentMonth() {
  if (!state.current) return;
  const m = state.current;
  const activeMonthLabel = `${monthNames[m.month - 1]} ${m.year}`;
  els.monthTitle.textContent = activeMonthLabel;
  if (els.sidebarMonthLabel) els.sidebarMonthLabel.textContent = activeMonthLabel;
  els.yearChartTitle.textContent = `Ahorro por mes · ${m.year}`;
  els.currencyInput.value = m.currency;
  els.exchangeRateInput.value = m.exchange_rate || "";
  els.incomeUsdInput.value = m.income_total || "";
  els.targetInput.value = m.target_savings_usd || "";
  els.actualSavingsInput.value = m.actual_savings_usd || "";
  els.notesInput.value = m.notes || "";
  els.entryDayInput.max = daysInMonth(m.year, m.month);
  const today = new Date();
  if (today.getFullYear() === Number(m.year) && today.getMonth() + 1 === Number(m.month)) {
    els.entryDayInput.value = today.getDate();
  } else if (!els.entryDayInput.value || Number(els.entryDayInput.value) > daysInMonth(m.year, m.month)) {
    els.entryDayInput.value = 1;
  }

  renderExpenseList("fixed");
  renderExpenseList("variable");
  renderStats();
  renderCalendar();
  renderYearBars();
}

function getIncomeArs(month = state.current) {
  return Number(month?.income_total || 0) * Number(month?.exchange_rate || 0);
}

function getTotals(month = state.current) {
  const fixed = (month.fixed_expenses || []).reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const fixedPaid = (month.fixed_expenses || []).filter((item) => item.paid).reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const variable = (month.variable_expenses || []).reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const daily = (month.daily_entries || []).reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const totalExpenses = fixed + variable + daily;
  const incomeArs = getIncomeArs(month);
  const available = incomeArs - totalExpenses;
  return { fixed, fixedPaid, fixedPending: Math.max(fixed - fixedPaid, 0), variable, daily, totalExpenses, incomeArs, available };
}


function getVariableBudget(month = state.current) {
  if (!month) return 0;
  const totals = getTotals(month);
  const plannedVariable = Number(totals.variable || 0);
  const savingsArs = Number(month.target_savings_usd || 0) * Number(month.exchange_rate || 0);

  // Si hay presupuesto variable cargado, se usa como el Excel: ese total es el margen para vivir el mes.
  // Si no hay presupuesto variable, se calcula el margen disponible después de fijos y ahorro objetivo.
  if (plannedVariable > 0) return plannedVariable;
  return Math.max(totals.incomeArs - totals.fixed - savingsArs, 0);
}

function getDailyBudget(month = state.current) {
  if (!month) return 0;
  const maxDay = daysInMonth(month.year, month.month);
  return Math.max(getVariableBudget(month) / Math.max(maxDay, 1), 0);
}

function getSpentUntil(day, month = state.current, includeDay = true) {
  return (month?.daily_entries || [])
    .filter((entry) => includeDay ? Number(entry.day) <= Number(day) : Number(entry.day) < Number(day))
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function getBudgetPlan(day = getSelectedDay(), month = state.current) {
  if (!month) {
    return { baseDaily: 0, variableBudget: 0, adjustedToday: 0, spentBefore: 0, spentToday: 0, spentToDate: 0, budgetToDate: 0, balanceToday: 0, balanceToDate: 0, nextDaily: 0, weeklyBudget: 0 };
  }
  const maxDay = daysInMonth(month.year, month.month);
  const safeDay = Math.max(1, Math.min(maxDay, Number(day || 1)));
  const variableBudget = getVariableBudget(month);
  const baseDaily = getDailyBudget(month);
  const spentBefore = getSpentUntil(safeDay, month, false);
  const spentToday = getDailySpent(safeDay, month);
  const spentToDate = spentBefore + spentToday;
  const remainingDaysIncludingToday = Math.max(maxDay - safeDay + 1, 1);
  const remainingDaysAfterToday = Math.max(maxDay - safeDay, 0);
  const adjustedToday = Math.max((variableBudget - spentBefore) / remainingDaysIncludingToday, 0);
  const remainingAfterToday = variableBudget - spentToDate;
  const nextDaily = remainingDaysAfterToday > 0 ? Math.max(remainingAfterToday / remainingDaysAfterToday, 0) : Math.max(remainingAfterToday, 0);
  const budgetToDate = baseDaily * safeDay;
  const balanceToDate = budgetToDate - spentToDate;
  return {
    baseDaily,
    variableBudget,
    adjustedToday,
    spentBefore,
    spentToday,
    spentToDate,
    budgetToDate,
    balanceToday: adjustedToday - spentToday,
    balanceToDate,
    nextDaily,
    weeklyBudget: baseDaily * 7
  };
}

function getSelectedDay() {
  if (!state.current) return 1;
  const maxDay = daysInMonth(state.current.year, state.current.month);
  const raw = Number(els.entryDayInput?.value || 1);
  return Math.max(1, Math.min(maxDay, raw || 1));
}

function getDailySpent(day = getSelectedDay(), month = state.current) {
  return (month?.daily_entries || [])
    .filter((entry) => Number(entry.day) === Number(day))
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
}

function getDayEntries(day = getSelectedDay(), month = state.current) {
  return (month?.daily_entries || []).filter((entry) => Number(entry.day) === Number(day));
}

function getDayStatus(spent, budget) {
  if (!budget || budget <= 0) {
    return {
      key: "limit",
      title: "Sin presupuesto diario",
      text: "No hay margen diario porque ingresos, fijos, variables o ahorro objetivo consumen el mes. Revisá el plan.",
      label: "Sin margen",
      emoji: "⚠️",
      meme: dailyStatusMemes.limit
    };
  }
  const ratio = spent / budget;
  if (ratio > 1.25) {
    return {
      key: "drama",
      title: "Te fuiste fuerte del presupuesto",
      text: "Hoy ya pasaste bastante el tope. Conviene compensar en los próximos días para no romper la meta de ahorro.",
      label: "Pasada fuerte",
      emoji: "😭",
      meme: dailyStatusMemes.drama
    };
  }
  if (ratio > 1) {
    return {
      key: "over",
      title: "Te pasaste del presupuesto",
      text: "El gasto real del día superó lo presupuestado. Todavía se puede corregir compensando mañana.",
      label: "Pasada",
      emoji: "🥲",
      meme: dailyStatusMemes.over
    };
  }
  if (ratio >= 0.8) {
    return {
      key: "limit",
      title: "Estás al límite",
      text: "Vas cerca del tope diario. Cuidado con los gastos hormiga o compras impulsivas.",
      label: "Al límite",
      emoji: "😳",
      meme: dailyStatusMemes.limit
    };
  }
  return {
    key: "ok",
    title: "Vas bien",
    text: "Estás dentro del presupuesto diario. Si mantenés este ritmo, protegés la meta de ahorro.",
    label: "OK",
    emoji: "😏",
    meme: dailyStatusMemes.ok
  };
}

function getDailyCategorySummary(day = getSelectedDay(), month = state.current) {
  const entries = getDayEntries(day, month);
  const totals = new Map();
  entries.forEach((entry) => {
    const cat = entry.category || "Otros";
    totals.set(cat, (totals.get(cat) || 0) + Number(entry.amount || 0));
  });
  return [...totals.entries()].sort((a, b) => b[1] - a[1]);
}

function renderDailyStatus() {
  if (!state.current || !els.dailyStatusCard) return;
  const currency = state.current.currency || "ARS";
  const day = getSelectedDay();
  const plan = getBudgetPlan(day, state.current);
  const budget = plan.adjustedToday;
  const spent = plan.spentToday;
  const balance = plan.balanceToday;
  const status = getDayStatus(spent, budget);
  const pct = budget > 0 ? clampPercent((spent / budget) * 100) : 100;

  if (els.dailyBudgetView) els.dailyBudgetView.textContent = formatMoney(plan.baseDaily, currency);
  if (els.weeklyBudgetView) els.weeklyBudgetView.textContent = formatMoney(plan.weeklyBudget, currency);
  if (els.selectedDaySpentView) els.selectedDaySpentView.textContent = formatMoney(spent, currency);
  if (els.selectedDayBalanceView) els.selectedDayBalanceView.textContent = formatMoney(balance, currency);
  if (els.selectedAccumBudgetView) els.selectedAccumBudgetView.textContent = formatMoney(plan.budgetToDate, currency);
  if (els.selectedAccumSpentView) els.selectedAccumSpentView.textContent = formatMoney(plan.spentToDate, currency);
  if (els.selectedAccumBalanceView) els.selectedAccumBalanceView.textContent = formatMoney(plan.balanceToDate, currency);
  if (els.compensatedDailyView) els.compensatedDailyView.textContent = formatMoney(budget, currency);

  els.dailyStatusCard.className = `daily-status-card status-${status.key}`;
  els.dailyStatusMeme.src = status.meme;
  els.dailyStatusTitle.textContent = `${status.emoji} ${status.title}`;
  els.dailyStatusText.textContent = `Día ${day}: gastaste ${formatMoney(spent, currency)} de un tope ajustado de ${formatMoney(budget, currency)} (${formatPercent(pct)}). Acumulado del mes: ${formatMoney(plan.spentToDate, currency)} vs ${formatMoney(plan.budgetToDate, currency)}. ${status.text}`;
  els.dailyBudgetMini.textContent = `Base diario: ${formatMoney(plan.baseDaily, currency)}`;
  els.dailySpentMini.textContent = `Gastado hoy: ${formatMoney(spent, currency)}`;
  els.dailyBalanceMini.textContent = `Compensación acumulada: ${formatMoney(plan.balanceToDate, currency)}`;
}

function buildWhatsAppSummary() {
  if (!state.current) return "";
  const currency = state.current.currency || "ARS";
  const day = getSelectedDay();
  const plan = getBudgetPlan(day, state.current);
  const budget = plan.adjustedToday;
  const spent = plan.spentToday;
  const balance = plan.balanceToday;
  const status = getDayStatus(spent, budget);
  const week = getWeekForDay(day, state.current);
  const categories = getDailyCategorySummary(day, state.current);
  const monthLabel = `${monthNames[state.current.month - 1]} ${state.current.year}`;
  const catText = categories.length
    ? categories.map(([cat, amount]) => `• ${cat}: ${formatMoney(amount, currency)}`).join("\n")
    : "• Sin gastos cargados todavía";
  const weekText = week
    ? `${week.label} · ${formatMoney(week.spent, currency)} de ${formatMoney(week.budget, currency)} · saldo ${formatMoney(week.balance, currency)}`
    : "Sin datos";

  return `Resumen financiero diario
${monthLabel} · Día ${day}

Estado: ${status.emoji} ${status.label}
Tope diario compensado: ${formatMoney(budget, currency)}
Tope diario base: ${formatMoney(plan.baseDaily, currency)}
Gastado hoy: ${formatMoney(spent, currency)}
Saldo del día: ${formatMoney(balance, currency)}
Acumulado del mes: ${formatMoney(plan.spentToDate, currency)} / ${formatMoney(plan.budgetToDate, currency)}
Compensación acumulada: ${formatMoney(plan.balanceToDate, currency)}
Semana actual: ${weekText}

Gasto por categoría:
${catText}

Meta ahorro mensual: ${formatUsd(state.current.target_savings_usd)}
Ahorro real cargado: ${formatUsd(state.current.actual_savings_usd)}

${status.text}`;
}

function openWhatsAppSummary() {
  const text = buildWhatsAppSummary();
  if (!text) return;
  const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
  window.open(url, "_blank", "noopener,noreferrer");
}

function renderStats() {
  const m = state.current;
  const totals = getTotals(m);
  const monthProgress = clampPercent((Number(m.actual_savings_usd || 0) / Math.max(Number(m.target_savings_usd || 0), 1)) * 100);
  const totalSaved = state.months.reduce((sum, item) => sum + Number(item.actual_savings_usd || 0), 0);
  const totalGoal = state.months.reduce((sum, item) => sum + Number(item.target_savings_usd || 0), 0) || (DEFAULT_TARGET_USD * MONTH_COUNT);
  const globalProgress = clampPercent((totalSaved / Math.max(totalGoal, 1)) * 100);
  const currency = m.currency || "ARS";

  els.monthCircle.style.setProperty("--p", monthProgress.toFixed(1));
  els.monthPercent.textContent = `${Math.round(monthProgress)}%`;
  els.incomeConvertedView.textContent = formatMoney(totals.incomeArs, currency);
  els.incomeTotalView.textContent = formatMoney(totals.incomeArs, currency);
  els.incomeArsViewInput.value = formatMoney(totals.incomeArs, currency);
  els.targetSavingsView.textContent = formatUsd(m.target_savings_usd);
  els.actualSavingsView.textContent = formatUsd(m.actual_savings_usd);
  els.totalSavedView.textContent = formatUsd(totalSaved);
  els.fiveYearGoalView.textContent = formatUsd(totalGoal);
  els.globalPercent.textContent = `${Math.round(globalProgress)}%`;
  els.globalProgressBar.style.width = `${globalProgress}%`;
  els.globalSavedLabel.textContent = `${formatUsd(totalSaved)} ahorrados`;
  els.globalRemainingLabel.textContent = `Faltan ${formatUsd(Math.max(totalGoal - totalSaved, 0))}`;

  els.fixedTotalView.textContent = formatMoney(totals.fixed, currency);
  els.fixedPaidView.textContent = formatMoney(totals.fixedPaid, currency);
  els.fixedPendingView.textContent = formatMoney(totals.fixedPending, currency);
  els.variableTotalView.textContent = formatMoney(totals.variable, currency);
  els.dailyTotalView.textContent = formatMoney(totals.daily, currency);
  els.availableView.textContent = formatMoney(totals.available, currency);
  renderDailyStatus();
  renderCategoryBreakdown();
  renderWeeklyBreakdown();
  renderGoals();
}

function renderExpenseList(type) {
  const listEl = type === "fixed" ? els.fixedList : els.variableList;
  const key = type === "fixed" ? "fixed_expenses" : "variable_expenses";
  listEl.innerHTML = "";

  if (!state.current[key].length) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = type === "fixed" ? "Todavía no cargaste gastos fijos." : "Todavía no cargaste gastos variables.";
    listEl.appendChild(empty);
    return;
  }

  state.current[key].forEach((item, index) => {
    const node = els.expenseTemplate.content.firstElementChild.cloneNode(true);
    const paidCell = node.querySelector(".paid-cell");
    const paid = node.querySelector(".expense-paid");
    const icon = node.querySelector(".expense-icon");
    const category = node.querySelector(".expense-category");
    const name = node.querySelector(".expense-name");
    const amount = node.querySelector(".expense-amount");
    const remove = node.querySelector(".remove-btn");

    const normalized = normalizeExpense(item, type);
    icon.value = normalized.icon;
    category.value = normalized.category;
    name.value = normalized.name;
    amount.value = Number(normalized.amount || 0) || "";
    paid.checked = Boolean(normalized.paid);
    node.classList.toggle("is-paid", paid.checked);

    if (type !== "fixed") {
      paidCell.classList.add("hidden-paid");
    }

    const persistRow = () => {
      state.current[key][index] = {
        icon: icon.value,
        category: category.value,
        name: name.value,
        amount: Number(amount.value || 0),
        paid: type === "fixed" ? Boolean(paid.checked) : false
      };
      node.classList.toggle("is-paid", paid.checked);
      updateMonthInMemory();
      renderStats();
      scheduleSave();
    };

    [icon, category, name, amount].forEach((field) => field.addEventListener("input", persistRow));
    paid.addEventListener("change", persistRow);

    remove.addEventListener("click", () => {
      state.current[key].splice(index, 1);
      updateMonthInMemory();
      renderExpenseList(type);
      renderStats();
      scheduleSave();
    });

    listEl.appendChild(node);
  });
}

function addExpense(type) {
  const key = type === "fixed" ? "fixed_expenses" : "variable_expenses";
  state.current[key].push({
    icon: type === "fixed" ? "🏠" : "🧾",
    category: type === "fixed" ? "Casa" : "Otros",
    name: "",
    amount: 0,
    paid: false
  });
  updateMonthInMemory();
  renderExpenseList(type);
  renderStats();
  scheduleSave();
}

function addDailyEntry() {
  const day = Number(els.entryDayInput.value || 1);
  const maxDay = daysInMonth(state.current.year, state.current.month);
  if (day < 1 || day > maxDay) {
    alert(`Ese mes tiene días del 1 al ${maxDay}.`);
    return;
  }
  const amount = Number(els.entryAmountInput.value || 0);
  if (amount <= 0) {
    alert("Cargá un monto mayor a cero.");
    return;
  }
  const category = els.entryCategoryInput.value;
  const note = els.entryNoteInput.value.trim();
  state.current.daily_entries.push({
    id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
    day,
    category,
    amount,
    note,
    created_at: new Date().toISOString()
  });
  els.entryAmountInput.value = "";
  els.entryNoteInput.value = "";
  updateMonthInMemory();
  renderStats();
  renderCalendar();
  scheduleSave();
}

function getCategoryTotals() {
  const totals = new Map();
  const add = (category, amount) => {
    const cat = category || "Otros";
    totals.set(cat, (totals.get(cat) || 0) + Number(amount || 0));
  };
  (state.current?.fixed_expenses || []).forEach((item) => add(item.category, item.amount));
  (state.current?.variable_expenses || []).forEach((item) => add(item.category, item.amount));
  (state.current?.daily_entries || []).forEach((item) => add(item.category, item.amount));
  return [...totals.entries()].sort((a, b) => b[1] - a[1]);
}

function renderCategoryBreakdown() {
  if (!els.categoryBreakdown || !state.current) return;
  const totals = getCategoryTotals();
  const totalExpense = totals.reduce((sum, [, amount]) => sum + amount, 0);
  const currency = state.current.currency || "ARS";
  els.categoryBreakdown.innerHTML = "";

  if (!totals.length || totalExpense <= 0) {
    els.categoryBreakdown.innerHTML = `<p class="muted">Cargá gastos para ver la composición por categoría.</p>`;
    return;
  }

  totals.forEach(([category, amount]) => {
    const pct = (amount / totalExpense) * 100;
    const row = document.createElement("div");
    row.className = "category-row";
    row.innerHTML = `
      <div class="category-top">
        <span>${categoryIcons[category] || "✨"} ${category}</span>
        <strong>${formatPercent(pct)}</strong>
      </div>
      <div class="category-bar"><span style="width:${clampPercent(pct)}%"></span></div>
      <div class="category-foot">${formatMoney(amount, currency)} de ${formatMoney(totalExpense, currency)}</div>
    `;
    els.categoryBreakdown.appendChild(row);
  });
}

function getWeekRanges(month = state.current) {
  if (!month) return [];
  const maxDay = daysInMonth(month.year, month.month);
  const ranges = [];
  let start = 1;
  let index = 1;
  while (start <= maxDay) {
    const end = Math.min(start + 6, maxDay);
    ranges.push({ index, start, end, days: end - start + 1, label: `Semana ${index}` });
    start = end + 1;
    index += 1;
  }
  return ranges;
}

function getWeekSummaries(month = state.current) {
  if (!month) return [];
  const baseDaily = getDailyBudget(month);
  const variableBudget = getVariableBudget(month);
  const maxDay = daysInMonth(month.year, month.month);
  return getWeekRanges(month).map((range) => {
    const spent = (month.daily_entries || [])
      .filter((entry) => Number(entry.day) >= range.start && Number(entry.day) <= range.end)
      .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
    const budget = baseDaily * range.days;
    const balance = budget - spent;
    const spentToEnd = getSpentUntil(range.end, month, true);
    const budgetToEnd = baseDaily * range.end;
    const balanceToEnd = budgetToEnd - spentToEnd;
    const remainingDays = Math.max(maxDay - range.end, 0);
    const nextDaily = remainingDays > 0 ? Math.max((variableBudget - spentToEnd) / remainingDays, 0) : 0;
    const status = getDayStatus(spent, budget);
    return { ...range, spent, budget, balance, spentToEnd, budgetToEnd, balanceToEnd, nextDaily, status };
  });
}

function getWeekForDay(day = getSelectedDay(), month = state.current) {
  return getWeekSummaries(month).find((week) => Number(day) >= week.start && Number(day) <= week.end);
}

function renderWeeklyBreakdown() {
  if (!els.weeklyBreakdown || !state.current) return;
  const currency = state.current.currency || "ARS";
  const weeks = getWeekSummaries(state.current);
  els.weeklyBreakdown.innerHTML = "";

  if (!weeks.length) {
    els.weeklyBreakdown.innerHTML = `<p class="muted">Todavía no hay semanas para mostrar.</p>`;
    return;
  }

  weeks.forEach((week) => {
    const card = document.createElement("div");
    card.className = `weekly-card weekly-${week.status.key}`;
    const balanceClass = week.balance < 0 ? "negative" : "positive";
    const accClass = week.balanceToEnd < 0 ? "negative" : "positive";
    card.innerHTML = `
      <div class="weekly-top">
        <strong>${week.status.emoji} ${week.label}</strong>
        <span>Días ${week.start}-${week.end}</span>
      </div>
      <div class="weekly-metric"><span>Presupuesto semana</span><strong>${formatMoney(week.budget, currency)}</strong></div>
      <div class="weekly-metric"><span>Gastado semana</span><strong>${formatMoney(week.spent, currency)}</strong></div>
      <div class="weekly-metric ${balanceClass}"><span>Saldo semana</span><strong>${formatMoney(week.balance, currency)}</strong></div>
      <div class="weekly-metric ${accClass}"><span>Compensado acumulado</span><strong>${formatMoney(week.balanceToEnd, currency)}</strong></div>
      <div class="weekly-note">Tope diario sugerido después de esta semana: <b>${formatMoney(week.nextDaily, currency)}</b></div>
    `;
    els.weeklyBreakdown.appendChild(card);
  });
}

function renderCalendar() {
  const m = state.current;
  const currency = m.currency || "ARS";
  const maxDay = daysInMonth(m.year, m.month);
  els.calendarGrid.innerHTML = "";

  for (let day = 1; day <= maxDay; day++) {
    const entries = (m.daily_entries || []).filter((entry) => Number(entry.day) === day);
    const total = entries.reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
    const plan = getBudgetPlan(day, m);
    const budget = plan.adjustedToday;
    const baseBudget = plan.baseDaily;
    const balance = budget - total;
    const status = getDayStatus(total, budget);
    const selected = Number(els.entryDayInput?.value || 0) === day;
    const card = document.createElement("div");
    card.className = `day-card ${entries.length ? "has-entry" : ""} day-status-${status.key} ${selected ? "selected-day" : ""}`;
    card.innerHTML = `
      <div class="day-num">Día ${day} <span>${status.emoji}</span></div>
      <div class="day-total">Gastado: ${entries.length ? formatMoney(total, currency) : formatMoney(0, currency)}</div>
      <div class="day-budget-line">Base: ${formatMoney(baseBudget, currency)}</div>
      <div class="day-budget-line">Ajustado: ${formatMoney(budget, currency)}</div>
      <div class="day-diff ${balance < 0 ? "negative" : "positive"}">${balance < 0 ? "Te pasaste" : "Saldo"}: ${formatMoney(balance, currency)}</div>
    `;

    card.addEventListener("click", (event) => {
      if (event.target?.classList?.contains("entry-delete")) return;
      els.entryDayInput.value = day;
      renderDailyStatus();
      renderCalendar();
    });

    entries.slice(0, 4).forEach((entry) => {
      const item = document.createElement("div");
      item.className = "day-entry";
      item.innerHTML = `
        <span>${categoryIcons[entry.category] || "✨"} ${entry.category}${entry.note ? ` · ${entry.note}` : ""}</span>
        <button class="entry-delete" type="button" title="Eliminar">×</button>
      `;
      item.querySelector("button").addEventListener("click", () => deleteEntry(entry.id));
      card.appendChild(item);
    });

    if (entries.length > 4) {
      const more = document.createElement("small");
      more.className = "muted";
      more.textContent = `+ ${entries.length - 4} más`;
      card.appendChild(more);
    }

    els.calendarGrid.appendChild(card);
  }
}

function deleteEntry(id) {
  state.current.daily_entries = state.current.daily_entries.filter((entry) => entry.id !== id);
  updateMonthInMemory();
  renderStats();
  renderCalendar();
  scheduleSave();
}

function renderYearBars() {
  const year = state.current.year;
  const months = state.months.filter((m) => Number(m.year) === Number(year));
  els.yearBars.innerHTML = "";

  for (let month = 1; month <= 12; month++) {
    const row = months.find((m) => Number(m.month) === month);
    const target = Number(row?.target_savings_usd || DEFAULT_TARGET_USD);
    const actual = Number(row?.actual_savings_usd || 0);
    const progress = clampPercent((actual / Math.max(target, 1)) * 100);
    const cell = document.createElement("div");
    cell.className = "bar-cell";
    cell.innerHTML = `
      <div class="bar-track"><div class="bar-fill" style="height:${Math.max(progress, 3)}%"></div></div>
      <span>${shortMonths[month - 1]}</span>
      <small>${Math.round(progress)}%</small>
    `;
    els.yearBars.appendChild(cell);
  }
}

function updateCurrentFromInputs() {
  if (!state.current) return;
  state.current.currency = els.currencyInput.value.trim() || "ARS";
  state.current.exchange_rate = Number(els.exchangeRateInput.value || 0);
  state.current.income_total = Number(els.incomeUsdInput.value || 0);
  state.current.target_savings_usd = Number(els.targetInput.value || 0);
  state.current.actual_savings_usd = Number(els.actualSavingsInput.value || 0);
  state.current.notes = els.notesInput.value.trim();
  updateMonthInMemory();
  renderStats();
  renderYearBars();
}

function updateMonthInMemory() {
  const index = state.months.findIndex((m) => m.id === state.current?.id);
  if (index >= 0) {
    state.months[index] = { ...state.months[index], ...state.current };
  }
}

function scheduleSave() {
  if (state.isBootstrapping) return;
  setSaveStatus("Guardando...", "saving");
  clearTimeout(state.savingTimer);
  state.savingTimer = setTimeout(() => saveCurrentMonth(), 650);
}

async function saveCurrentMonth() {
  if (!state.current || !state.user) return;
  updateCurrentFromInputs();
  setSaveStatus("Guardando...", "saving");
  const payload = {
    currency: state.current.currency,
    exchange_rate: state.current.exchange_rate,
    income_total: state.current.income_total,
    target_savings_usd: state.current.target_savings_usd,
    actual_savings_usd: state.current.actual_savings_usd,
    fixed_expenses: state.current.fixed_expenses,
    variable_expenses: state.current.variable_expenses,
    daily_entries: state.current.daily_entries,
    notes: state.current.notes,
    updated_at: new Date().toISOString()
  };

  const { error } = await client
    .from("finance_months")
    .update(payload)
    .eq("id", state.current.id)
    .eq("user_id", state.user.id);

  if (error) {
    console.error(error);
    setSaveStatus("Error al guardar", "error");
    return;
  }
  setSaveStatus("Guardado online", "saved");
}

async function clearCurrentMonth() {
  if (!confirm("¿Seguro? Esto limpia variables, gastos diarios y destilda los fijos pagados. Mantiene tus gastos fijos cargados.")) return;
  state.current.fixed_expenses = cleanFixedExpenses(state.current.fixed_expenses).map((item) => ({ ...item, paid: false }));
  state.current.variable_expenses = [];
  state.current.daily_entries = [];
  state.current.actual_savings_usd = 0;
  state.current.notes = "";
  updateMonthInMemory();
  renderCurrentMonth();
  await saveCurrentMonth();
}

async function addGoal() {
  if (!state.goalsEnabled) {
    alert("Primero ejecutá el SQL actualizado de metas en Supabase. Está dentro del ZIP como supabase-update-metas.sql.");
    return;
  }
  const name = els.goalNameInput.value.trim();
  const target = Number(els.goalTargetInput.value || 0);
  const saved = Number(els.goalSavedInput.value || 0);
  const monthly = Number(els.goalMonthlyInput.value || DEFAULT_TARGET_USD);
  const icon = els.goalIconInput.value || "🎯";
  if (!name || target <= 0) {
    alert("Cargá nombre de la meta y monto objetivo mayor a cero.");
    return;
  }
  const payload = {
    user_id: state.user.id,
    icon,
    name,
    target_amount_usd: target,
    saved_amount_usd: saved,
    monthly_contribution_usd: monthly
  };
  const { data, error } = await client.from("savings_goals").insert(payload).select().single();
  if (error) {
    alert(`No pude guardar la meta. Detalle: ${error.message}`);
    return;
  }
  state.goals.push(data);
  els.goalNameInput.value = "";
  els.goalTargetInput.value = "";
  els.goalSavedInput.value = "0";
  els.goalMonthlyInput.value = String(state.current?.target_savings_usd || DEFAULT_TARGET_USD);
  renderGoals();
}

function renderGoals() {
  if (!els.goalsList) return;
  els.goalsList.innerHTML = "";

  if (!state.goalsEnabled) {
    els.goalsList.innerHTML = `<div class="goal-card warning">⚠️ Falta ejecutar el SQL de metas. Corré <strong>supabase-update-metas.sql</strong> en Supabase para activar esta sección.</div>`;
    return;
  }

  if (!state.goals.length) {
    els.goalsList.innerHTML = `<p class="muted">Todavía no cargaste metas. Probá con “Comprar moto” y el monto objetivo en USD.</p>`;
    return;
  }

  state.goals.forEach((goal, index) => {
    const target = Number(goal.target_amount_usd || 0);
    const saved = Number(goal.saved_amount_usd || 0);
    const monthly = Number(goal.monthly_contribution_usd || 0);
    const remaining = Math.max(target - saved, 0);
    const progress = clampPercent((saved / Math.max(target, 1)) * 100);
    const monthsLeft = monthly > 0 ? Math.ceil(remaining / monthly) : null;
    const projected = monthsLeft === null ? "Sin aporte mensual" : (remaining <= 0 ? "Meta cumplida" : addMonths(new Date(), monthsLeft));

    const card = document.createElement("div");
    card.className = "goal-card";
    card.innerHTML = `
      <div class="goal-main">
        <div class="goal-icon">${goal.icon || "🎯"}</div>
        <div>
          <input class="goal-name" value="${escapeHtml(goal.name || "")}" />
          <small>${formatUsd(saved)} de ${formatUsd(target)}</small>
        </div>
        <button class="remove-btn goal-remove" type="button" title="Eliminar">×</button>
      </div>
      <div class="progress-bar"><span style="width:${progress}%"></span></div>
      <div class="goal-grid">
        <label>Monto objetivo USD<input class="goal-target" type="number" min="0" step="0.01" value="${target}" /></label>
        <label>Ya ahorrado USD<input class="goal-saved" type="number" min="0" step="0.01" value="${saved}" /></label>
        <label>Aporte mensual USD<input class="goal-monthly" type="number" min="0" step="0.01" value="${monthly}" /></label>
      </div>
      <div class="goal-meta">
        <span>${Math.round(progress)}% completado</span>
        <span>Faltan ${formatUsd(remaining)}</span>
        <span>Proyección: ${projected}</span>
      </div>
    `;

    const saveInline = () => {
      const updated = {
        ...state.goals[index],
        name: card.querySelector(".goal-name").value.trim(),
        target_amount_usd: Number(card.querySelector(".goal-target").value || 0),
        saved_amount_usd: Number(card.querySelector(".goal-saved").value || 0),
        monthly_contribution_usd: Number(card.querySelector(".goal-monthly").value || 0)
      };
      state.goals[index] = updated;
      scheduleGoalSave(updated);
      renderGoals();
    };

    card.querySelector(".goal-remove").addEventListener("click", () => deleteGoal(goal.id));
    [".goal-name", ".goal-target", ".goal-saved", ".goal-monthly"].forEach((selector) => {
      card.querySelector(selector).addEventListener("change", saveInline);
    });

    els.goalsList.appendChild(card);
  });
}

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function scheduleGoalSave(goal) {
  clearTimeout(state.goalSavingTimer);
  state.goalSavingTimer = setTimeout(async () => {
    const { error } = await client
      .from("savings_goals")
      .update({
        name: goal.name,
        target_amount_usd: goal.target_amount_usd,
        saved_amount_usd: goal.saved_amount_usd,
        monthly_contribution_usd: goal.monthly_contribution_usd,
        updated_at: new Date().toISOString()
      })
      .eq("id", goal.id)
      .eq("user_id", state.user.id);
    if (error) console.error(error);
  }, 450);
}

async function deleteGoal(id) {
  if (!confirm("¿Eliminar esta meta?")) return;
  const { error } = await client.from("savings_goals").delete().eq("id", id).eq("user_id", state.user.id);
  if (error) {
    alert(error.message);
    return;
  }
  state.goals = state.goals.filter((goal) => goal.id !== id);
  renderGoals();
}

function attachEvents() {
  els.loginTab.addEventListener("click", () => setAuthMode("login"));
  els.signupTab.addEventListener("click", () => setAuthMode("signup"));
  els.authForm.addEventListener("submit", handleAuthSubmit);
  els.logoutBtn.addEventListener("click", logout);
  els.seedBtn.addEventListener("click", async () => {
    try {
      await ensureMonths();
      renderMonthOptions();
      selectMonth(state.current?.month_key || getMonthKey(START_YEAR, START_MONTH));
    } catch (error) {
      alert(error.message);
    }
  });
  els.resetMonthBtn.addEventListener("click", clearCurrentMonth);
  els.restoreTemplateBtn.addEventListener("click", restorePersonalExcelTemplate);
  els.flowPrevBtn?.addEventListener("click", prevFlowStep);
  els.flowNextBtn?.addEventListener("click", nextFlowStep);
  els.flowToggleBtn?.addEventListener("click", toggleFlowMode);
  attachFlowSwipe();

  els.monthSelect.addEventListener("change", () => selectMonth(els.monthSelect.value));
  els.saveNowBtn.addEventListener("click", saveCurrentMonth);
  els.addFixedBtn.addEventListener("click", () => addExpense("fixed"));
  els.addVariableBtn.addEventListener("click", () => addExpense("variable"));
  els.addEntryBtn.addEventListener("click", addDailyEntry);
  els.entryDayInput.addEventListener("input", () => {
    renderDailyStatus();
    renderCalendar();
  });
  els.whatsappSummaryBtn.addEventListener("click", openWhatsAppSummary);
  els.clearMonthBtn.addEventListener("click", clearCurrentMonth);
  els.addGoalBtn.addEventListener("click", addGoal);

  [els.currencyInput, els.exchangeRateInput, els.incomeUsdInput, els.targetInput, els.actualSavingsInput, els.notesInput].forEach((input) => {
    input.addEventListener("input", () => {
      updateCurrentFromInputs();
      scheduleSave();
    });
  });

  els.goalMonthlyInput.value = String(DEFAULT_TARGET_USD);
}

attachEvents();
renderFlowNav();
setAuthMode("login");

client.auth.onAuthStateChange((_event, session) => {
  state.session = session;
  state.user = session?.user || null;
});

bootApp();
