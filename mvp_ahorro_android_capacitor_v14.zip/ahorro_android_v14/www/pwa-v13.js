(() => {
  let deferredPrompt = null;
  const installBtn = document.getElementById('installAppBtn');

  const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const isIOS = () => /iphone|ipad|ipod/i.test(window.navigator.userAgent);

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch((error) => {
        console.warn('No se pudo registrar el service worker:', error);
      });
    });
  }

  function hideIfInstalled() {
    if (installBtn && isStandalone()) installBtn.classList.add('hidden');
  }

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferredPrompt = event;
    if (installBtn && !isStandalone()) installBtn.classList.remove('hidden');
  });

  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    if (installBtn) installBtn.classList.add('hidden');
  });

  if (installBtn) {
    installBtn.addEventListener('click', async () => {
      if (isStandalone()) {
        alert('La app ya está instalada en este dispositivo.');
        return;
      }

      if (deferredPrompt) {
        deferredPrompt.prompt();
        await deferredPrompt.userChoice;
        deferredPrompt = null;
        return;
      }

      if (isIOS()) {
        alert('Para instalarla en iPhone: tocá Compartir y después “Agregar a pantalla de inicio”.');
        return;
      }

      alert('Para instalarla: abrí el menú del navegador y elegí “Instalar app” o “Agregar a pantalla principal”.');
    });
  }

  hideIfInstalled();
})();
